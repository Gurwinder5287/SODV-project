﻿using System;

namespace Connect4
{
    public class Connect4Game
    {
        private const int Rows = 6;
        private const int Columns = 7;

        private char[,] board;
        private char currentPlayer;
        private bool gameOver;

        public Connect4Game()
        {
            board = new char[Rows, Columns];
            currentPlayer = 'X';
            gameOver = false;
            InitializeBoard();
        }

        public void Play()
        {
            Console.WriteLine("Welcome to Connect 4!");

            while (!gameOver)
            {
                PrintBoard();
                Console.WriteLine($"Player {currentPlayer}, choose a column (1-{Columns}):");

                int column;
                while (!int.TryParse(Console.ReadLine(), out column) || column < 1 || column > Columns || !IsColumnAvailable(column))
                {
                    Console.WriteLine("Invalid input. Please choose an available column (1-{Columns}):");
                }

                DropDisc(column);
                if (CheckForWin())
                {
                    PrintBoard();
                    Console.WriteLine($"Player {currentPlayer} wins!");
                    gameOver = true;
                }
                else if (IsBoardFull())
                {
                    PrintBoard();
                    Console.WriteLine("The game ends in a draw!");
                    gameOver = true;
                }
                else
                {
                    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                }
            }

            Console.WriteLine("Thank you for playing Connect 4!");
        }

        private void InitializeBoard()
        {
            for (int row = 0; row < Rows; row++)
            {
                for (int col = 0; col < Columns; col++)
                {
                    board[row, col] = '-';
                }
            }
        }

        private void PrintBoard()
        {
            for (int row = 0; row < Rows; row++)
            {
                for (int col = 0; col < Columns; col++)
                {
                    Console.Write(board[row, col] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        private bool IsColumnAvailable(int column)
        {
            return board[0, column - 1] == '-';
        }

        private void DropDisc(int column)
        {
            for (int row = Rows - 1; row >= 0; row--)
            {
                if (board[row, column - 1] == '-')
                {
                    board[row, column - 1] = currentPlayer;
                    break;
                }
            }
        }

        private bool CheckForWin()
        {
            // Check horizontal
            for (int row = 0; row < Rows; row++)
            {
                for (int col = 0; col < Columns - 3; col++)
                {
                    if (board[row, col] != '-' && board[row, col] == board[row, col + 1] && board[row, col] == board[row, col + 2] && board[row, col] == board[row, col + 3])
                    {
                        return true;
                    }
                }
            }

            // Check vertical
            for (int row = 0; row < Rows - 3; row++)
            {
                for (int col = 0; col < Columns; col++)
                {
                    if (board[row, col] != '-' && board[row, col] == board[row + 1, col] && board[row, col] == board[row + 2, col] && board[row, col] == board[row + 3, col])
                    {
                        return true;
                    }
                }
            }

            // Check diagonal (top left to bottom right)
            for (int row = 0; row < Rows - 3; row++)
            {
                for (int col = 0; col < Columns - 3; col++)
                {
                    if (board[row, col] != '-' && board[row, col] == board[row + 1, col + 1] && board[row, col] == board[row + 2, col + 2] && board[row, col] == board[row + 3, col + 3])
                    {
                        return true;
                    }
                }
            }

            // Check diagonal (top right to bottom left)
            for (int row = 0; row < Rows - 3; row++)
            {
                for (int col = 3; col < Columns; col++)
                {
                    if (board[row, col] != '-' && board[row, col] == board[row + 1, col - 1] && board[row, col] == board[row + 2, col - 2] && board[row, col] == board[row + 3, col - 3])
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private bool IsBoardFull()
        {
            for (int col = 0; col < Columns; col++)
            {
                if (board[0, col] == '-')
                {
                    return false;
                }
            }
            return true;
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            Connect4Game game = new Connect4Game();
            game.Play();
        }
    }
}